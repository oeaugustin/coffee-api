document.getElementById("click").onclick
function pickCoffee(){
  
}
